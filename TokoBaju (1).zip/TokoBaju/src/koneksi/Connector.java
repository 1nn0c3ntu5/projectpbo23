/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package koneksi;

import com.mysql.cj.jdbc.MysqlDataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author lenovo
 */
public class Connector {
    private static Connection connection;
    
    public static Connection getConnection(){
        if(connection==null){
            MysqlDataSource data = new MysqlDataSource();
            data.setDatabaseName("tokobaju");
            data.setUser("root");
            data.setPassword("");
            try{
                connection = data.getConnection();
                System.out.println("Koneksi berhasil");
            }catch(SQLException ex){
                ex.printStackTrace();
                Logger.getLogger(Connector.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("Koneksi gagal");
            }
        }
      
        return connection;
    }
}
