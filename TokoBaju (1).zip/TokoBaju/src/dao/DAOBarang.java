/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import DAOimplement.Service_Barang;
import java.util.ArrayList;
import model.ModelBarang;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import koneksi.Connector;
import model.ModelJenis;


/**
 *
 * @author lenovo
 */
public class DAOBarang implements Service_Barang {
    
    private Connection con;
    
    public DAOBarang(){
        con = Connector.getConnection();
    }

    @Override
    public void insert(ModelBarang mod_bar) {
        PreparedStatement st = null;
        String sql = "INSERT INTO data_barang (id_barang, id_jenis, merk, ukuran, harga, stok) VALUES (?,?,?,?,?,?)";
        try{
            st = con.prepareStatement(sql);
            
            st.setString(1, mod_bar.getId_barang());
            st.setString(2, mod_bar.getJenis_barang().getId_jenis());
            st.setString(3, mod_bar.getMerk());
            st.setString(4, mod_bar.getUkuran());
            st.setLong(5, mod_bar.getHarga());
            st.setInt(6, mod_bar.getStok());
            
            st.executeUpdate();
        } catch(SQLException ex){
            Logger.getLogger(DAOBarang.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
             if (st!= null){
               try{
                   st.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOBarang.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
        }
    }

    @Override
    public void update(ModelBarang mod_bar) {
       PreparedStatement st = null;
        String sql = "UPDATE data_barang SET id_jenis=?, merk=?, ukuran=?, harga=?, stok=? WHERE id_barang='"+ mod_bar.getId_barang()+"'";
        try{
            st = con.prepareStatement(sql);
            
            st.setString(1, mod_bar.getJenis_barang().getId_jenis());
            st.setString(2, mod_bar.getMerk());
            st.setString(3, mod_bar.getUkuran());
            st.setLong(4, mod_bar.getHarga());
            st.setInt(5, mod_bar.getStok());
            
            st.executeUpdate();
            
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Perbarui Data Gagal");
            Logger.getLogger(DAOBarang.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
             if (st!= null){
               try{
                   st.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOBarang.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
        }
    }

    @Override
    public void delete(ModelBarang mod_bar) {
        PreparedStatement st = null;
        String sql = "DELETE FROM data_barang WHERE id_barang=?";
        try{
            st = con.prepareStatement(sql);
            
            st.setString(1, mod_bar.getId_barang());
            
            
            st.executeUpdate();
        } catch(SQLException ex){
            Logger.getLogger(DAOBarang.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
             if (st!= null){
               try{
                   st.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOBarang.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
        }
    }

    @Override
    public ModelBarang getByid(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<ModelBarang> getDataByID() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<ModelBarang> getData() {
        PreparedStatement st = null;
        List list = new ArrayList();
        ResultSet rs = null;
        String sql = "SELECT bg.id_barang, bg.id_jenis, jb.nama_jenis, bg.merk, bg.ukuran, bg.harga, bg.stok FROM data_barang bg INNER JOIN jenis_barang jb ON jb.id_jenis=bg.id_jenis";
        try {
           st = con.prepareStatement(sql);
           rs = st.executeQuery();
           while(rs.next()){
               ModelBarang mobar = new ModelBarang();
               ModelJenis jbr = new ModelJenis();
               
               mobar.setId_barang(rs.getString("id_barang"));
               jbr.setId_jenis(rs.getString("id_jenis"));
               jbr.setNama_jenis(rs.getString("nama_jenis"));
               mobar.setMerk(rs.getString("Merk"));
               mobar.setUkuran(rs.getString("ukuran"));
               mobar.setHarga(rs.getLong("harga"));
               mobar.setStok(rs.getInt("Stok"));
               
               mobar.setJenis_barang(jbr);
               
               list.add(mobar);
           }
           return list;
        }catch (SQLException ex){
            Logger.getLogger(DAOBarang.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }finally{
            if (st!= null){
               try{
                   st.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOBarang.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
            if (rs!=null){
               try{
                   rs.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOBarang.class.getName()).log(Level.SEVERE, null, ex);
                
            }
        }
    }
 
}
    

    @Override
    public List<ModelBarang> search(String id) {
        PreparedStatement st = null;
        List list = new ArrayList();
        ResultSet rs = null;
        String sql = "SELECT bg.id_barang, bg.id_jenis, jb.nama_jenis,"
                + "bg.merk, bg.ukuran, bg.harga, bg.stok FROM data_barang bg "
                + "INNER JOIN jenis_barang jb ON jb.id_jenis=bg.id_jenis WHERE id_barang LIKE '%"+id+"%'";
        try {
           st = con.prepareStatement(sql);
           rs = st.executeQuery();
           while(rs.next()){
               ModelBarang mobar = new ModelBarang();
               ModelJenis jbr = new ModelJenis();
               
               mobar.setId_barang(rs.getString("id_barang"));
               jbr.setId_jenis(rs.getString("id_jenis"));
               jbr.setNama_jenis(rs.getString("nama_jenis"));
               mobar.setMerk(rs.getString("Merk"));
               mobar.setUkuran(rs.getString("ukuran"));
               mobar.setHarga(rs.getLong("harga"));
               mobar.setStok(rs.getInt("Stok"));
               
               mobar.setJenis_barang(jbr);
               list.add(mobar);
           }
           return list;
        }catch (SQLException ex){
            Logger.getLogger(DAOBarang.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }finally{
            if (st!= null){
               try{
                   st.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOBarang.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
            if (rs!=null){
               try{
                   rs.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOBarang.class.getName()).log(Level.SEVERE, null, ex);
                
            }
        }
    }
 
}

    @Override
    public List<ModelBarang> search2(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String nomor() {
        PreparedStatement st = null;
        ResultSet rs = null;
        String urutan = null;
        
        Date now = new Date();
        SimpleDateFormat tanggal = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat noformat = new SimpleDateFormat("yyMM");
        String tgl = tanggal.format(now);
        String no = noformat.format(now);
        
        String sql  = "SELECT RIGHT(id_barang, 3) AS Nomor " + 
                "FROM data_barang " +
                "WHERE id_barang LIKE 'B" + no + "%' " +
                "ORDER BY id_barang DESC " +
                "LIMIT 1";
        try{
            st = con.prepareStatement(sql);
            rs = st.executeQuery();
            
            if(rs.next()){
                int nomor = Integer.parseInt(rs.getString("Nomor"));
                nomor++;
                urutan = "B" + no + String.format("%03d", nomor);
            }else{
                urutan = "B" + no + "001";
            }
        }catch(SQLException ex){
             Logger.getLogger(DAOBarang.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            if (st!= null){
               try{
                   st.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOBarang.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
        }
        return urutan;
    }

    @Override
    public String nomor2() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
