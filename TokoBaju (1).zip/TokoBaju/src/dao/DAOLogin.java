/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import DAOimplement.Service_Login;
import model.ModelLogin;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import koneksi.Connector;
import view.LoginView;
import view.MainMenu;


/**
 *
 * @author lenovo
 */
public class DAOLogin implements Service_Login{
    private Connection con;
    
    public DAOLogin(){
        con = Connector.getConnection();
    }
    @Override
    public void prosesLogin(ModelLogin login) {
       PreparedStatement st = null;
       ResultSet rs = null;
       String Id = null;
       String Nama = null;
       
       String sql = "SELECT * FROM user WHERE(id='"+ login.getId()
               +"'OR username='"+login.getUsername()
               +"')AND password='"+Encrypt.getmd5java(login.getPassword())+"'";
       
       try{
           st = con.prepareStatement(sql);
           rs = st.executeQuery();
           if(rs.next()){
               Id = rs.getString("id");
               Nama = rs.getString("nama");
               
               MainMenu menu = new MainMenu(Id, Nama);
               menu.setVisible(true);
               menu.revalidate();
               
               LoginView lg = new LoginView();
               lg.tutup = true;
           }else{
               JOptionPane.showMessageDialog(null, "Username dan Password salah", "Pesan", JOptionPane.INFORMATION_MESSAGE);
               LoginView lg = new LoginView();
               lg.tutup = false;
           }
       }catch(SQLException ex){
           Logger.getLogger(DAOLogin.class.getName()).log(Level.SEVERE, null, ex);
       }finally{
           if (st!= null){
               try{
                   st.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOLogin.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
       }
    }
    
}
