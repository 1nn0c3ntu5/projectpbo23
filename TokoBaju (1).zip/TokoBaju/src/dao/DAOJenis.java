/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;
import model.ModelBarang;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import koneksi.Connector;
import DAOimplement.Service_Jenis;
import java.util.List;
import model.ModelJenis;

/**
 *
 * @author lenovo
 */
public class DAOJenis implements Service_Jenis{

    private Connection connection;
    
    public DAOJenis(){
        connection = Connector.getConnection();
    }
    
    @Override
    public void insert(ModelJenis mod_jen) {
        PreparedStatement st = null;
        String sql = "INSERT INTO jenis_barang(id_jenis, nama_jenis)VALUES (?,?)";
        try {
           st = connection.prepareStatement(sql);
           
           st.setString(1, mod_jen.getId_jenis());
           st.setString(2, mod_jen.getNama_jenis());
           
           st.executeUpdate();
           }catch (SQLException ex){
            Logger.getLogger(DAOJenis.class.getName()).log(Level.SEVERE, null, ex);
           }finally{
            if (st!= null){
               try{
                   st.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOJenis.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
        }
    }

    @Override
    public void update(ModelJenis mod_jen) {
        PreparedStatement st = null;
        String sql = "UPDATE jenis_barang SET nama_jenis=? WHERE id_jenis=?";
        try {
           st = connection.prepareStatement(sql);
           
           st.setString(1, mod_jen.getId_jenis());
           st.setString(2, mod_jen.getNama_jenis());
           
           st.executeUpdate();
           
           }catch (SQLException ex){
            Logger.getLogger(DAOJenis.class.getName()).log(Level.SEVERE, null, ex);
           }finally{
            if (st!= null){
               try{
                   st.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOJenis.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
        }
    }
       

    @Override
    public void delete(ModelJenis mod_jen) {
         PreparedStatement st = null;
        String sql = "DELETE FROM jenis_barang WHERE id_jenis=?";
        try{
            st = connection.prepareStatement(sql);
            
            st.setString(1, mod_jen.getId_jenis());
            
            
            st.executeUpdate();
        } catch(SQLException ex){
            Logger.getLogger(DAOJenis.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
             if (st!= null){
               try{
                   st.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOJenis.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
        }
    }

    @Override
    public ModelJenis getByid(String id) {
       PreparedStatement st = null;
       ResultSet rs = null;
       ModelJenis mokat = null;
       String sql = "SELECT * FROM jenis_barang WHERE id_jenis=?";
       
       try {
           st = connection.prepareStatement(sql);
           ModelJenis ang = new ModelJenis();
           st.setString(1, ang.getId_jenis());
           st.setString(2, ang.getNama_jenis());
           
            rs = st.executeQuery();
            
            while(rs.next()){
                mokat = new ModelJenis();
                mokat.setId_jenis(rs.getString("id_jenis"));
                mokat.setNama_jenis(rs.getString("nama_jenis"));
            }
            return mokat;
           }catch (SQLException ex){
            Logger.getLogger(DAOJenis.class.getName()).log(Level.SEVERE, null, ex);
            return null;
           }finally{
            if (st!= null){
               try{
                   st.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOJenis.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
            if (rs!=null){
               try{
                   rs.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOJenis.class.getName()).log(Level.SEVERE, null, ex);
                
            }
        }
    }
 }

    @Override
    public List<ModelJenis> getData() {
        PreparedStatement st = null;
        List list = new ArrayList();
        ResultSet rs = null;
        String sql = "SELECT * FROM jenis_barang";
        try {
           st = connection.prepareStatement(sql);
           rs = st.executeQuery();
           while(rs.next()){
               ModelJenis mokat = new ModelJenis();
               
               mokat.setId_jenis(rs.getString("id_jenis"));
               mokat.setNama_jenis(rs.getString("nama_jenis"));
               
               list.add(mokat);
           }
           return list;
        }catch (SQLException ex){
            Logger.getLogger(DAOJenis.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }finally{
            if (st!= null){
               try{
                   st.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOJenis.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
            if (rs!=null){
               try{
                   rs.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOJenis.class.getName()).log(Level.SEVERE, null, ex);
                
            }
        }
    }
    }

    @Override
    public List<ModelJenis> getData2() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<ModelJenis> search(String id) {
        PreparedStatement st = null;
        List list = new ArrayList();
        ResultSet rs = null;
        String sql = "SELECT * from jenis_barang WHERE id_jenis LIKE '%" +id+"%'";
        try {
           st = connection.prepareStatement(sql);
           rs = st.executeQuery();
           while(rs.next()){
               ModelJenis jbr = new ModelJenis();
              
               jbr.setId_jenis(rs.getString("id_jenis"));
               jbr.setNama_jenis(rs.getString("nama_jenis"));
               
               list.add(jbr);
           }
           return list;
        }catch (SQLException ex){
            Logger.getLogger(DAOBarang.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }finally{
            if (st!= null){
               try{
                   st.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOBarang.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
            if (rs!=null){
               try{
                   rs.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOBarang.class.getName()).log(Level.SEVERE, null, ex);
                
            }
         }
    }
 }       

    @Override
    public List<ModelJenis> search2(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String nomor() {
       PreparedStatement st = null;
       ResultSet rs = null;
       String urutan = null;
       String sql = "SELECT RIGHT(id_jenis,3) AS Nomor FROM jenis_barang ORDER BY Nomor DESC LIMIT 1";
       try {
           st = connection.prepareStatement(sql);
           rs = st.executeQuery();
           if(rs.next()){
               int nomor = Integer.parseInt(rs.getString("Nomor"));
               nomor++;
               urutan = String.format("JB%03d", nomor);
           }else{
               urutan = "JB001";
           }
       }catch(SQLException ex){
           Logger.getLogger(DAOJenis.class.getName()).log(Level.SEVERE, null, ex);
       }finally{
         if (st!= null){
               try{
                   st.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOJenis.class.getName()).log(Level.SEVERE, null, ex);
               }
           }  
       }
       return urutan;
    }

    @Override
    public boolean validasiNamaJenisBarang(ModelJenis mod_jen) {
        PreparedStatement st  = null;
        ResultSet rs = null;
        boolean valid = false;
        
        String sql = "SELECT nama_jenis FROM jenis_barang WHERE id_jenis!='"+mod_jen.getId_jenis()+"' AND nama_jenis LIKE BINARY '"+ mod_jen.getNama_jenis()+"';";
        
        try{
            st = connection.prepareStatement(sql);
            rs = st.executeQuery();
            
            if(rs.next()){
                JOptionPane.showMessageDialog(null, "Nama Jenis Barang Telah Ada\nSilahkan mengisi nama jenis barang yang lain", "Peringatan", JOptionPane.WARNING_MESSAGE);
            }else{
                valid = true;
            }
        }catch(SQLException ex){
             Logger.getLogger(DAOJenis.class.getName()).log(Level.SEVERE, null, ex);
       }finally{
         if (st!= null){
               try{
                   st.close();
               }catch(SQLException ex){
               Logger.getLogger(DAOJenis.class.getName()).log(Level.SEVERE, null, ex);
               }
           }  
        }
        
        return valid;
    }
}
