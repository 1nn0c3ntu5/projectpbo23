/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOimplement;

import java.util.List;
import model.ModelJenis;

/**
 *
 * @author lenovo
 */
public interface Service_Jenis {
    public void insert(ModelJenis mod_jen);
    public void update(ModelJenis mod_jen);
    public void delete(ModelJenis mod_jen);
    
    ModelJenis getByid(String id);
    
    List<ModelJenis> getData();
    List<ModelJenis> getData2();
    
    List<ModelJenis> search(String id);
    List<ModelJenis> search2(String id);
    
    String nomor();
    
    boolean validasiNamaJenisBarang(ModelJenis mod_jen);
}
