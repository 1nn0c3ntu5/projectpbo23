/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOimplement;

import java.util.List;
import model.ModelStaf;

/**
 *
 * @author lenovo
 */
public interface Service_Staf {
    public void insert(ModelStaf mod_staf);
    public void update(ModelStaf mod_staf);
    public void delete(ModelStaf mod_staf);
    
    ModelStaf getByid(String id);
    
    List<ModelStaf> getData(); 
    List<ModelStaf> search(String id);   
    String nomor();

}
