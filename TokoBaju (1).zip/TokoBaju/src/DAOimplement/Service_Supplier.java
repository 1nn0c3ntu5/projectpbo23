/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOimplement;

import java.util.List;
import model.ModelSupplier;


/**
 *
 * @author lenovo
 */
public interface Service_Supplier {
    public void insert(ModelSupplier mod_sup);
    public void update(ModelSupplier mod_sup);
    public void delete(ModelSupplier mod_sup);
    
    ModelSupplier getByid(String id);
    
    List<ModelSupplier> getData();
    List<ModelSupplier> search(String id);

    String nomor();
    
}
