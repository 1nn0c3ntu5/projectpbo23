/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author lenovo
 */
public class ModelSupplier {
    private String id_supplier;
    private String nama_supplier;
    private Integer nomorHp_supplier;
    private String alamat_supplier;

    public String getId_supplier() {
        return id_supplier;
    }

    public void setId_supplier(String id_supplier) {
        this.id_supplier = id_supplier;
    }

    public String getNama_supplier() {
        return nama_supplier;
    }

    public void setNama_supplier(String nama_supplier) {
        this.nama_supplier = nama_supplier;
    }

    public Integer getNomorHp_supplier() {
        return nomorHp_supplier;
    }

    public void setNomorHp_supplier(Integer nomorHp_supplier) {
        this.nomorHp_supplier = nomorHp_supplier;
    }

    public String getAlamat_supplier() {
        return alamat_supplier;
    }

    public void setAlamat_supplier(String alamat_supplier) {
        this.alamat_supplier = alamat_supplier;
    }
    
    
}
