/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author lenovo
 */
public class ModelStaf {
    private String id_staf;
    private String nama_staf;
    private Integer nomorHp_staf;
    private String alamat_staf;

    public String getId_staf() {
        return id_staf;
    }

    public void setId_staf(String id_staf) {
        this.id_staf = id_staf;
    }

    public String getNama_staf() {
        return nama_staf;
    }

    public void setNama_staf(String nama_staf) {
        this.nama_staf = nama_staf;
    }

    public Integer getNomorHp_staf() {
        return nomorHp_staf;
    }

    public void setNomorHp_staf(Integer nomorHp_staf) {
        this.nomorHp_staf = nomorHp_staf;
    }

    public String getAlamat_staf() {
        return alamat_staf;
    }

    public void setAlamat_staf(String alamat_staf) {
        this.alamat_staf = alamat_staf;
    }
    
    
            
}
