/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TabelModel;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import model.ModelBarang;

/**
 *
 * @author lenovo
 */
public class TabelMod_Barang extends AbstractTableModel{
    
    private List<ModelBarang> list = new ArrayList<>();
    
    public void insert(ModelBarang mod_bar){
        list.add(mod_bar);
        fireTableRowsInserted(list.size()-1, list.size() -1);
        JOptionPane.showMessageDialog(null, "Data Berhasil ditambahkan");
    }
    
    public void update(int row, ModelBarang mod_bar){
        list.add(row, mod_bar);
        fireTableDataChanged();
        JOptionPane.showMessageDialog(null, "Data Berhasil diperbarui");
    }
    
    public void delete(int index){
        list.remove(index);
        fireTableRowsDeleted(index, index);
        JOptionPane.showMessageDialog(null, "Data Berhasil dihapus");
    }
    
    public void clear(){
        list.clear();
        fireTableDataChanged();
    }
    
    public void setData(List<ModelBarang> list){
        clear();
        this.list.addAll(list);
        fireTableDataChanged();
    }
    
    public void setData(int index, ModelBarang mod_bar){
        list.set(index, mod_bar);
        fireTableCellUpdated(index, index);
    }
    
    public ModelBarang getData(int index){
        return list.get(index);
    }
        
    @Override
    public int getRowCount() {
        return list.size();
    }

    private final String[] columnNames = {"No", "Id Barang", "Id Jenis", "Nama Jenis", "Merk", "Ukuran", "Harga", "Stok"};
    
    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int row, int column) {
        if(column == 0){
            return "   " + (row + 1);
        } else {
        switch (column - 1){
            case 0: return list.get(row).getId_barang();
            case 1: return list.get(row).getJenis_barang().getId_jenis();
            case 2: return list.get(row).getJenis_barang().getNama_jenis();
            case 3: return list.get(row).getMerk();
            case 4: return list.get(row).getUkuran();
            case 5: return list.get(row).getHarga();
            case 6: return list.get(row).getStok();
            default: return null;
        }
      }      
    }
    
       @Override
    public String getColumnName(int column){
        if (column == 0 ){
            return "   " + columnNames[column];
        }else{
            return columnNames[column];
        }
    }
    
}
       

