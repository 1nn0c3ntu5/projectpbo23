/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TabelModel;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import model.ModelStaf;

/**
 *
 * @author lenovo
 */
public class TabelMod_Staf extends AbstractTableModel{

    private List<ModelStaf> list = new ArrayList<>();
    
    public void insert(ModelStaf mod_staf){
        list.add(mod_staf);
        fireTableRowsInserted(list.size()-1, list.size() -1);
        JOptionPane.showMessageDialog(null, "Data Berhasil ditambahkan");
    }
    
    public void update(int row, ModelStaf mod_staf){
        list.add(row, mod_staf);
        fireTableDataChanged();
        JOptionPane.showMessageDialog(null, "Data Berhasil diperbarui");
    }
    
    public void delete(int index){
        list.remove(index);
        fireTableRowsDeleted(index, index);
        JOptionPane.showMessageDialog(null, "Data Berhasil dihapus");
    }
    
    public void clear(){
        list.clear();
        fireTableDataChanged();
    }
    
    public void setData(List<ModelStaf> list){
        clear();
        this.list.addAll(list);
        fireTableDataChanged();
    }
    
    public void setData(int index, ModelStaf mod_staf){
        list.set(index, mod_staf);
        fireTableCellUpdated(index, index);
    }
    
    public ModelStaf getData(int index){
        return list.get(index);
    }
        
    @Override
    public int getRowCount() {
        return list.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch (column){
            case 0: return list.get(row).getId_staf();
            case 1: return list.get(row).getNama_staf();
            case 2: return list.get(row).getNomorHp_staf();
            case 3: return list.get(row).getAlamat_staf();
            default: return null;
        }      
    }
    
       @Override
    public String getColumnName(int column){
        switch(column){
            case 0:
                return "ID Staf";
            case 1:
                return "Nama Staf";
            case 2:
                return "Nomor Staf";
            case 3:
                return "Alamat Staf";
            default:
                return null;
        }
    }
    
}
