/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TabelModel;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import model.ModelJenis;

/**
 *
 * @author lenovo
 */
public class TabelMod_Jenis extends AbstractTableModel{

    private List<ModelJenis> list = new ArrayList<>();
    
    public void insert(ModelJenis mod_jen){
        list.add(mod_jen);
        fireTableRowsInserted(list.size()-1, list.size() -1);
        JOptionPane.showMessageDialog(null, "Data Berhasil ditambahkan");
    }
    
    public void update(int row, ModelJenis mod_jen){
        list.add(row, mod_jen);
        fireTableDataChanged();
        JOptionPane.showMessageDialog(null, "Data Berhasil diperbarui");
    }
    
    public void delete(int index){
        list.remove(index);
        fireTableRowsDeleted(index, index);
        JOptionPane.showMessageDialog(null, "Data Berhasil dihapus");
    }
    
    public void clear(){
        list.clear();
        fireTableDataChanged();
    }
    
    public void setData(List<ModelJenis> list){
        clear();
        this.list.addAll(list);
        fireTableDataChanged();
    }
    
    public void setData(int index, ModelJenis mod_jen){
        list.set(index, mod_jen);
        fireTableCellUpdated(index, index);
    }
    
    public ModelJenis getData(int index){
        return list.get(index);
    }
        
    @Override
    public int getRowCount() {
        return list.size();
    }

    @Override
    public int getColumnCount() {
        return 2;
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch (column){
            case 0: return list.get(row).getId_jenis();
            case 1: return list.get(row).getNama_jenis();
            default: return null;
        }      
    }
    
       @Override
    public String getColumnName(int column){
        switch(column){
            case 0:
                return "ID Jenis";
            case 1:
                return "Jenis Barang";
            default:
                return null;
        }
    }
    
}
